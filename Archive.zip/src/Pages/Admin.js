import React from "react";
import SignInForm from "../components/SignInForm";

const SignIn = () => {
  return (
    <div className="body_wrapper">
      <SignInForm />
    </div>
  );
};

export default SignIn;
