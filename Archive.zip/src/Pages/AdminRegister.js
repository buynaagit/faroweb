import React from "react";
import RegisterForm from "../components/RegisterForm";

const AdminRegister = () => {
  return (
    <div className="body_wrapper">
      <RegisterForm />
    </div>
  );
};

export default AdminRegister;
